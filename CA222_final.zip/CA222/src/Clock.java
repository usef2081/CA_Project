
public class Clock {
	
	int value;
	
	public Clock(int value) {
		
		this.value = value;
	}
	
	public void incrementClock(PCreg pc){
		value++;
		System.out.println(" \n \n -------------------------------------------------------------------------------------\n  " + " Start of Cycle  " + value );
		System.out.println("Program Counter =  " + pc.value  );
		
	}

}
