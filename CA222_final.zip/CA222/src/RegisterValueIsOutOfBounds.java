public class RegisterValueIsOutOfBounds extends Exception {

    public RegisterValueIsOutOfBounds(String message) {
        super(message);
    }

}