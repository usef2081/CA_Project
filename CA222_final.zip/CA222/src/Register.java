public class Register {
    String name;
    int value;
    // A register can maximum hold a value represented by 8 bits, which is 255

    public Register(String name, int value) throws RegisterValueIsOutOfBounds {
        this.name = name;
        if (value > 255 || value < -256) {
            throw new RegisterValueIsOutOfBounds("Register value is out of bounds");
        }
        else {
            this.value = value;
        }

    }
    
    public String toString () {
    	
    	return ("name: " + name + "--------------------------> value: " + value);
    }
    
    public void setValue (int x) throws RegisterValueIsOutOfBounds {

    	value = x;
    	System.out.println("Value of Register " + name + " is updated to :  " + x);
    }
    
    
    public void setStatusRegisterToZero() {
    	
    	value = 0;
    }

}