
public class PCreg {
	
    String name;
    int value;
 // A PC register can maximum hold a value represented by 16 bits, which is 65535
    
    public PCreg(String name, int value) throws RegisterValueIsOutOfBounds {
        this.name = name;
        if (value > 65535 || value < 0) {
            throw new RegisterValueIsOutOfBounds("Register value is out of bounds");
        }
        else {
            this.value = value;
        }

    }
    
    public String toString () {
    	
    	return ("name: " + name + " value: " + value);
    }
    
    public void setValue (int x) {
    	
    	value = x;
    	System.out.println("Value of  " + name + " is updated to :  " + x);
    }

}
