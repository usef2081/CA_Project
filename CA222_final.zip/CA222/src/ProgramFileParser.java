import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Scanner;
import java.util.Stack;

public class ProgramFileParser {
	
	
	static Stack<String []> instructions;
	 
	public ProgramFileParser(String pathname) throws IOException {
		
		
		instructions = new Stack <String []>();
		readFile(pathname);
		
	}
	
	

    static void readFile(String pathname) throws IOException {
        String currentLine="";
        ArrayList <String> res = new ArrayList<String>();
        FileReader fileReader = new FileReader(pathname);
        BufferedReader br = new BufferedReader(fileReader);
        while((currentLine = br.readLine()) != null){
            String [] result= currentLine.split("/n");
            for(int i=0; i<result.length; i++) {
            	String [] tmp = currentLine.split(" ");
            	instructions.add(tmp);
            	
            	
            }
                
    }  
        Stack<String []> tmp = new Stack <String []>();
        while(instructions.isEmpty() == false) {
        	
        	tmp.push(instructions.pop());
        }
        instructions = tmp;
    }
    
    
    public Stack<String []> getInstructions (){
    	
    	
    	
    	return instructions;
    }
    
    
    
    public static void main (String [] args) throws IOException {
    	
    	
    ProgramFileParser p = new ProgramFileParser("Program.txt");
    /* while(instructions.isEmpty() == false) {
    	
    	
    	String [] t = instructions.pop();
    	System.out.print(Arrays.asList(t));
    	

    	
    	
    }*/
    	
    //String [] v = {"ahmed","sjsjjs","sjsksk"};
	String [] t = instructions.pop();
	System.out.println(Arrays.asList(t));
    
	int i = 0b1001000000000000;
	int j =2;
	//System.out.println(Integer.toBinaryString(32));
	
	System.out.println(String.format("%8s", Integer.toBinaryString(-22)).replace(' ', '0'));
	
	int k = 0b1001000000000010;
    
    System.out.println(i|j);
    System.out.println(k);
    
    //System.out.print(Arrays.asList(v));
    }
    
  
}