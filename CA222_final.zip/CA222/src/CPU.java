import java.io.IOException;
import java.util.*;

public class CPU {
    ArrayList<Register> general_purpose_registers = new ArrayList<Register>(64);
    
    // 0 0 0 C V N S Z
    Register status = new Register("Status Register", 0);
    PCreg pc = new PCreg("Program Counter",0);
    Clock cycles = new Clock (1);
	ArrayList<Integer> instructions = new ArrayList<Integer>(1024);
	ArrayList<Integer> data = new ArrayList<Integer>(2048);
	int fetched_instruction =  0;
	

    


    CPU() throws RegisterValueIsOutOfBounds {
        this.initialize_general_purpose_registers();
    	for(int i =0; i<2048; i++) {
    		
    		data.add(null);
    		
    	}
    }
    
    
    void initializeInstructions(String pathname) throws IOException, RegisterValueIsOutOfBounds {
    	
    	
    	ProgramFileParser p = new ProgramFileParser(pathname);
    	Stack<String [] > stackOfInstructions = p.getInstructions();
    	
    	while(stackOfInstructions.isEmpty() == false) {
    		
    		String [] current = stackOfInstructions.pop();
    		String operation = current[0];
    		String O1 = current[1];
    		String O2 = current[2];
    		
    		
    		if(operation.equals("ADD")) {
    			
    			
    			int reg1 = Integer.parseInt(O1.substring(1));
    			
    			
    			int  reg2 = Integer.parseInt(O2.substring(1));
    			
    			
    			if(reg1 > 63|| reg2 >63 ||reg1<0)
    				throw new RegisterValueIsOutOfBounds("Out Of Bound");
    			
    			int tmp1 = 0b0000000000000000 | reg2;
    			int reg1tmp = 0b0000000000000000| reg1;
    			int reg1tmp1 = reg1tmp << 6;
    			
    			int codedInstruction = tmp1|reg1tmp1;
    			
    			this.instructions.add(codedInstruction);
    			
    			
    			
    		}
    		
    		
    		else if(operation.equals("SUB")) {
    			
    			int reg1 = Integer.parseInt(O1.substring(1));
    			
    			
    			int  reg2 = Integer.parseInt(O2.substring(1));
    			
    			
    			if(reg1 > 63|| reg2 >63 || reg1<0)
    				throw new RegisterValueIsOutOfBounds("Out Of Bound");
    			
    			int tmp1 = 0b0001000000000000 | reg2;
    			int reg1tmp = 0b0000000000000000| reg1;
    			int reg1tmp1 = reg1tmp << 6;
    			
    			int codedInstruction = tmp1|reg1tmp1;
    			
    			this.instructions.add(codedInstruction);
    			
    			
    			
    			
    			
    		}
    		else if(operation.equals("MUL")) {
    			
    			
    			int reg1 = Integer.parseInt(O1.substring(1));
    			
    			
    			int  reg2 = Integer.parseInt(O2.substring(1));
    			
    			
    			if(reg1 > 63|| reg2 >63 || reg1<0)
    				throw new RegisterValueIsOutOfBounds("Out Of Bound");
    			
    			int tmp1 = 0b0010000000000000 | reg2;
    			int reg1tmp = 0b0000000000000000| reg1;
    			int reg1tmp1 = reg1tmp << 6;
    			
    			int codedInstruction = tmp1|reg1tmp1;
    			
    			this.instructions.add(codedInstruction);
    			
    			
   	
    			
    		}
    		
    		
    		else if(operation.equals("MOVI")) {
    			
    			
    			int reg1no = Integer.parseInt(O1.substring(1));
    			
    			int  reg2no = Integer.parseInt(O2);
    			
    			if(reg1no > 63|| reg2no >63 || reg1no<0)
    				throw new RegisterValueIsOutOfBounds("Out Of Bound");
    			
    			int reg2no1 = reg2no & 0b00000000000000000000000000111111;
    			int tmp1 = 0b0011000000000000 | reg2no1;
    			int reg1tmp = 0b0000000000000000| reg1no;
    			int reg1tmp1 = reg1tmp << 6;
    			
    			int codedInstruction = tmp1|reg1tmp1;
    			
    			this.instructions.add(codedInstruction);
    			
    			
    			
    			
    		}
    		else if(operation.equals("BEQZ")){
    			
    			
    			
    			int reg1no = Integer.parseInt(O1.substring(1));
    			
    			int  reg2no = Integer.parseInt(O2);
    			
    			if(reg1no > 63|| reg2no >63 || reg1no<0)
    				throw new RegisterValueIsOutOfBounds("Out Of Bound");
    			
    			int reg2no1 = reg2no & 0b00000000000000000000000000111111;
    			int tmp1 = 0b0011000000000000 | reg2no1;
    			int reg1tmp = 0b0000000000000000| reg1no;
    			int reg1tmp1 = reg1tmp << 6;
    			
    			int codedInstruction = tmp1|reg1tmp1;
    			
    			this.instructions.add(codedInstruction);
    			
    			
    			
    			
    		}
    		else if(operation.equals("ANDI")) {
    			
    			int reg1no = Integer.parseInt(O1.substring(1));
    			
    			int  reg2no = Integer.parseInt(O2);
    			
    			if(reg1no > 63|| reg2no >63 || reg1no<0)
    				throw new RegisterValueIsOutOfBounds("Out Of Bound");
    			
    			int reg2no1 = reg2no & 0b00000000000000000000000000111111;
    			int tmp1 = 0b0011000000000000 | reg2no1;
    			int reg1tmp = 0b0000000000000000| reg1no;
    			int reg1tmp1 = reg1tmp << 6;
    			
    			int codedInstruction = tmp1|reg1tmp1;
    			
    			this.instructions.add(codedInstruction);
    			
    			
    		}
    		else if(operation.equals("EOR")) {
    			
    			
    			int reg1 = Integer.parseInt(O1.substring(1));
    			
    			
    			int  reg2 = Integer.parseInt(O2.substring(1));
    			
    			
    			if(reg1 > 63|| reg2 >63 || reg1<0)
    				throw new RegisterValueIsOutOfBounds("Out Of Bound");
    			
    			int tmp1 = 0b0110000000000000 | reg2;
    			int reg1tmp = 0b0000000000000000| reg1;
    			int reg1tmp1 = reg1tmp << 6;
    			
    			int codedInstruction = tmp1|reg1tmp1;
    			
    			this.instructions.add(codedInstruction);
    			
    			
    			
    			
    		}
    		else if(operation.equals("BR")) {
    			
    			
    			int reg1 = Integer.parseInt(O1.substring(1));
    			
    			
    			int  reg2 = Integer.parseInt(O2.substring(1));
    			
    			
    			if(reg1 > 63|| reg2 >63 || reg1<0)
    				throw new RegisterValueIsOutOfBounds("Out Of Bound");
    			
    			int tmp1 = 0b0111000000000000 | reg2;
    			int reg1tmp = 0b0000000000000000| reg1;
    			int reg1tmp1 = reg1tmp << 6;
    			
    			int codedInstruction = tmp1|reg1tmp1;
    			
    			this.instructions.add(codedInstruction);
    		}
    		else if(operation.equals("SAL")) {
    			
    			
    			int reg1no = Integer.parseInt(O1.substring(1));
    			
    			int  reg2no = Integer.parseInt(O2);
    			
    			if(reg1no > 63|| reg2no >63 || reg1no<0)
    				throw new RegisterValueIsOutOfBounds("Out Of Bound");
    			
    			int tmp1 = 0b1000000000000000 | reg2no;
    			int reg1tmp = 0b0000000000000000| reg1no;
    			int reg1tmp1 = reg1tmp << 6;
    			
    			int codedInstruction = tmp1|reg1tmp1;
    			
    			this.instructions.add(codedInstruction);
    			
    		}
    		else if(operation.equals("SAR")) {
    			int reg1no = Integer.parseInt(O1.substring(1));
    			
    			int  reg2no = Integer.parseInt(O2);
    			
    			if(reg1no > 63|| reg2no >63 || reg1no<0)
    				throw new RegisterValueIsOutOfBounds("Out Of Bound");
    			
    			int tmp1 = 0b1001000000000000 | reg2no;
    			int reg1tmp = 0b0000000000000000| reg1no;
    			int reg1tmp1 = reg1tmp << 6;
    			
    			int codedInstruction = tmp1|reg1tmp1;
    			
    			this.instructions.add(codedInstruction);
    		}
    		else if(operation.equals("LDR")) {
    			
    			int reg1no = Integer.parseInt(O1.substring(1));
    			
    			int  reg2no = Integer.parseInt(O2);
    			
    			if(reg1no > 63|| reg2no >63 || reg1no<0)
    				throw new RegisterValueIsOutOfBounds("Out Of Bound");
    			
    			int tmp1 = 0b1010000000000000 | reg2no;
    			int reg1tmp = 0b0000000000000000| reg1no;
    			int reg1tmp1 = reg1tmp << 6;
    			
    			int codedInstruction = tmp1|reg1tmp1;
    			
    			this.instructions.add(codedInstruction);
    		}
    		else if(operation.equals("STR")) {
    			
    			
    			int reg1no = Integer.parseInt(O1.substring(1));
    			
    			int  reg2no = Integer.parseInt(O2);
    			
    			if(reg1no > 63|| reg2no >63 || reg1no<0)
    				throw new RegisterValueIsOutOfBounds("Out Of Bound");
    			
    			int tmp1 = 0b1011000000000000 | reg2no;
    			int reg1tmp = 0b0000000000000000| reg1no;
    			int reg1tmp1 = reg1tmp << 6;
    			
    			int codedInstruction = tmp1|reg1tmp1;
    			
    			this.instructions.add(codedInstruction);
    		}	
    	}
    	
    }
    
    
    void start() throws RegisterValueIsOutOfBounds{
    		 fetch();
    	     decode(fetched_instruction);
    	     System.out.println("End of the Program \n \n ");
     		 System.out.println("Content of all Registers : \n" );
     		 for(int i =0; i<general_purpose_registers.size(); i++) {
     			 System.out.println(general_purpose_registers.get(i));
     		 }
     	     System.out.println("Content of Instruction Memory : \n " + instructions);
     	     
     	     
     	     System.out.println("Content of Data Memory : \n "); 
     	     
     	     for(int j =0; j<data.size(); j++) {
     	    	 System.out.println("At address " + j + "----------------> " + data.get(j));
     	    	 
     	     }
    		
    	}


    	
    	
    
    
    

    void fetch() throws RegisterValueIsOutOfBounds {
    	
    	int size = instructions.size();
    	if(pc.value < size) {
    		
    	    fetched_instruction = instructions.get(pc.value);
    		System.out.println("FETCHING : " + String.format("%16s", Integer.toBinaryString(fetched_instruction)).replace(' ', '0'));
    		pc.setValue(pc.value +1);
    		cycles.incrementClock(pc);

    	}
    	else {
    	
    		cycles.incrementClock(pc);}
    	}
    	

    	
 
    

    
    
    
    void decode(int instruction) throws RegisterValueIsOutOfBounds {

    	
    	
    	
    	int tmp = instruction | 0b0000000000000000;
    	int opcode = tmp>>> 12;
    	Register operand1 = null;
    	Register operand2 = null;
    	int immediate = 0;
    	char type;
    			
    	if(opcode == 0 || opcode == 1 || opcode == 2 || opcode == 6 || opcode == 7) {
    		
    		int tmp1 = tmp & 0b0000111111000000;
    		int i1 = tmp1 >>> 6;
    		operand1= general_purpose_registers.get(i1);
    		int i2 = tmp & 0b0000000000111111;
    		operand2 = general_purpose_registers.get(i2);
    		type = 'R';
    		
    		
    		if(cycles.value != 3 + (instructions.size() -1)){
    		System.out.println("DECODING :  " + instruction);
    	    System.out.println("Decoded Instruction for Next Cycle: - ");
    		System.out.println("OPCODE =  " + String.format("%4s", Integer.toBinaryString(opcode)).replace(' ', '0') + " REGISTER1:  " + String.format("%6s", Integer.toBinaryString(i1)).replace(' ', '0') + " REGISTER2: " + String.format("%6s", Integer.toBinaryString(i2)).replace(' ', '0')  );
    		System.out.println("OPCODEVALUE =  " + opcode + " REGISTER1INDEX:  " + i1 + "   REGISTER2INDEX: " + i2 );
    		System.out.println("Inputs For Next Cycle:-  ");
    		System.out.println("REGISTER1 :  Content = " + operand1.value + "\nREGISTER2 :  Content =  " + operand2.value );
   
    	}}
    	else {
    		
    		int tmp1 = tmp & 0b0000111111000000;
    		int i1 = tmp1 >>> 6;
    		operand1= general_purpose_registers.get(i1);
    		immediate = tmp & 0b0000000000111111;
            if(cycles.value != 3 + (instructions.size() -1)) {
    		System.out.println("OPCODE =  " + String.format("%4s", Integer.toBinaryString(opcode)).replace(' ', '0') + " REGISTER1:  " + String.format("%6s", Integer.toBinaryString(i1)).replace(' ', '0') + " IMM: " + String.format("%6s", Integer.toBinaryString(immediate)).replace(' ', '0')  );
            }
    		int sign = (instruction & 0b0000000000100000)>>>5;
    		if(sign == 1) {
    			int x = immediate ^ 0b111111;
    			int x1 = x+1;
    			immediate = x1 * -1;
    		}
    		type = 'I';
    		
    		if(cycles.value != 3 + (instructions.size() -1)) {
    		System.out.println("DECODING :  " + instruction);
    	    System.out.println("Decoded Instruction for Next Cycle: - ");	
    		System.out.println("OPCODEVALUE =  " + opcode + " REGISTER1INDEX:  " + i1 + " IMM_VALUE: " + immediate );
    		System.out.println("Inputs For Next Cycle:-  ");
    		System.out.println("REGISTER1 :  Content = " + operand1.value + "\nIMMEDIATE :  Content =  " + immediate );}
    		
    		
    		
    		
    		
    		
    	}
    	
    	if(type == 'R') {
    		
    		
    		fetch();
    		if(cycles.value <= (3 + (instructions.size() -1))) {
    	    System.out.println("EXECUTING :  " + String.format("%16s", Integer.toBinaryString(instruction)).replace(' ', '0'));
    		execute(opcode,operand1,operand2);
    		}
    	
    	}
    		
    	
    	if(type == 'I') {
    		fetch();
    		if(cycles.value <= (3 + (instructions.size() -1))) {
    		System.out.println("EXECUTING :  " + String.format("%16s", Integer.toBinaryString(instruction)).replace(' ', '0'));
    		execute(opcode,operand1,immediate);}}
    	
    
    	
    }

    void execute(int opcode, Register operand1, Register operand2) throws RegisterValueIsOutOfBounds {
    	
    	status.setStatusRegisterToZero();
    	if(opcode == 0) {
    		int tmpresult = operand1.value + operand2.value;
    		int result = tmpresult & 0b00000000000000000000000011111111;
    		int tmp1 = operand1.value & 0b00000000000000000000000011111111;
    		int tmp2 = operand2.value & 0b00000000000000000000000011111111;
    		int unsignedAdd = tmp1 + tmp2;
    		int mask =unsignedAdd & 0b00000000000000000000000100000000;
    		int check = unsignedAdd >>> 8;
    		boolean overflow = false;
    		boolean negative = false;
    		if(check == 1) {
    			int newStatus = status.value | 0b00010000;
    			status.setValue(newStatus);
    			System.out.println("There is a Carry \n \n");
    			
    		}
    		else {
    			int newStatus = status.value | 0b00000000;
    			status.setValue(newStatus);
    			System.out.println("There is no Carry \n \n");
    			
    		}
    		
    		
    		int sign1 = (operand1.value & 0b00000000000000000000000010000000)>>>7;
    		int sign2 = (operand2.value & 0b00000000000000000000000010000000)>>>7;
    		int resultSign = (result & 0b00000000000000000000000010000000)>>>7;
    		
    		
    		if(resultSign ==1) {
    			int x = result ^ 0b11111111;
    			int x1 = x+1;
    			result = x1 * -1;
    			int newStatus = status.value | 0b00000100;
    			status.setValue(newStatus);
    			System.out.println("The result is negative \n \n");
    			negative = true;
    			
    		}
    		else {
    			int newStatus = status.value | 0b00000000;
    			status.setValue(newStatus);
    			System.out.println("The result is not negative \n \n");
    			
    		}
    		
    		
    		if(((sign1 == sign2) && (sign1 == resultSign)) || sign1 != sign2) {
    			int newStatus = status.value | 0b00000000;
    			status.setValue(newStatus);
    			System.out.println("There is no Overflow \n \n");
    			
    			
    		}
    		else {
    			int newStatus = status.value | 0b00001000;
    			status.setValue(newStatus);
    			System.out.println("There is an Overflow \n \n");
    			overflow = true;
    			
    		}
    		
    		if ((overflow == true && negative == true) || (overflow == false && negative == false)) {
    			
    			int newStatus = status.value | 0b00000000;
    			status.setValue(newStatus);
    			System.out.println ("The Sign Flag is 0");
    		}
    		else {
    			int newStatus = status.value | 0b00000010;
    			status.setValue(newStatus);
    			System.out.println ("The Sign Flag is 1");
    			
    		}
    		
    		if(result == 0) {
    			int newStatus = status.value | 0b00000001;
    			status.setValue(newStatus);
    			System.out.println("The Zero Flag is 1");
    			
    		}
    		else {
    			int newStatus = status.value | 0b00000000;
    			status.setValue(newStatus);
    			System.out.println("The Zero Flag is 0");
    			
    		}
    		
    		
    		
    		
    		
    		int indexOfResult = Integer.parseInt(operand1.name.substring(1));
    		general_purpose_registers.get(indexOfResult).setValue(result);
    		
    	}
    	
    	
    	
    	
    	else if(opcode == 1){
    		int result = operand1.value - operand2.value;
    		int resultToBeStored = result & 0b00000000000000000000000011111111;
    		int indexOfResult = Integer.parseInt(operand1.name.substring(1));
    		boolean overflow = false;
    		boolean negative = false;

    		int resultSign = (resultToBeStored & 0b00000000000000000000000010000000)>>>7;
    		if(resultSign ==1) {
    			
    			
    			int x = resultToBeStored ^ 0b11111111;
    			int x1 = x+1;
    			resultToBeStored = x1 * -1;
    			int newStatus = status.value | 0b00000100;
    			status.setValue(newStatus);
    			System.out.println("The result is negative \n \n");
    			negative = true;
    			
    		}
    		else {
    			int newStatus = status.value | 0b00000000;
    			status.setValue(newStatus);
    			System.out.println("The result is not negative \n \n");
    			
    		}
    		
    		int sign1 = (operand1.value & 0b00000000000000000000000010000000)>>>7;
    		int sign2 = (operand2.value & 0b00000000000000000000000010000000)>>>7;
    		System.out.println(sign1);
    		System.out.println(sign2);
    		
    		
    		if((sign1 != sign2) && (resultSign == sign2)) {
    			
    			int newStatus = status.value | 0b00001000;
    			status.setValue(newStatus);
    			System.out.println("There is an Overflow \n \n");
    			overflow = true;
    			
    		}
    		else {
    			
    			int newStatus = status.value | 0b00000000;
    			status.setValue(newStatus);
    			System.out.println("There is no Overflow \n \n");
    			 	
    		}
    		
    		
    		if ((overflow == true && negative == true) || (overflow == false && negative == false)) {
    			
    			int newStatus = status.value | 0b00000000;
    			status.setValue(newStatus);
    			System.out.println ("The Sign Flag is 0");
    		}
    		else {
    			int newStatus = status.value | 0b00000010;
    			status.setValue(newStatus);
    			System.out.println ("The Sign Flag is 1");
    			
    		}
    		
    		if(resultToBeStored == 0) {
    			int newStatus = status.value | 0b00000001;
    			status.setValue(newStatus);
    			System.out.println("The Zero Flag is 1");
    			
    		}
    		else {
    			int newStatus = status.value | 0b00000000;
    			status.setValue(newStatus);
    			System.out.println("The Zero Flag is 0");
    			
    		}
    		
    		general_purpose_registers.get(indexOfResult).setValue(resultToBeStored);
    		
    	}
    	else if(opcode == 2){
    		
    		int result = operand1.value * operand2.value;
    		int resultToBeStored = result & 0b00000000000000000000000011111111;
    		int indexOfResult = Integer.parseInt(operand1.name.substring(1));
    		int resultSign = (resultToBeStored & 0b00000000000000000000000010000000)>>>7;
    		if(resultSign ==1) {
    			
    			
    			int x = resultToBeStored ^ 0b11111111;
    			int x1 = x+1;
    			resultToBeStored = x1 * -1;
    			int newStatus = status.value | 0b00000100;
    			status.setValue(newStatus);
    			System.out.println("The result is negative \n \n");
    			
    		}
    		else {
    			int newStatus = status.value | 0b00000000;
    			status.setValue(newStatus);
    			System.out.println("The result is not negative \n \n");
    			
    		}
    		
    		
    		if(resultToBeStored == 0) {
    			int newStatus = status.value | 0b00000001;
    			status.setValue(newStatus);
    			System.out.println("The Zero Flag is 1");
    			
    		}
    		else {
    			int newStatus = status.value | 0b00000000;
    			status.setValue(newStatus);
    			System.out.println("The Zero Flag is 0");
    			
    		}
    		
    		general_purpose_registers.get(indexOfResult).setValue(resultToBeStored);
    	}
    	else if(opcode == 6){
    		
    		int result = operand1.value ^ operand2.value;
    		int resultToBeStored = result & 0b00000000000000000000000011111111;
    		int indexOfResult = Integer.parseInt(operand1.name.substring(1));
    		int resultSign = (resultToBeStored & 0b00000000000000000000000010000000)>>>7;
    		if(resultSign ==1) {
    			
    			
    			int x = resultToBeStored ^ 0b11111111;
    			int x1 = x+1;
    			resultToBeStored = x1 * -1;
    			int newStatus = status.value | 0b00000100;
    			status.setValue(newStatus);
    			System.out.println("The result is negative \n \n");
    			
    		}
    		else {
    			int newStatus = status.value | 0b00000000;
    			status.setValue(newStatus);
    			System.out.println("The result is not negative \n \n");
    			
    		}
    		
    		if(resultToBeStored == 0) {
    			int newStatus = status.value | 0b00000001;
    			status.setValue(newStatus);
    			System.out.println("The Zero Flag is 1");
    			
    		}
    		else {
    			int newStatus = status.value | 0b00000000;
    			status.setValue(newStatus);
    			System.out.println("The Zero Flag is 0");
    			
    		}
    		
    		general_purpose_registers.get(indexOfResult).setValue(resultToBeStored);
    		
    	}
    	else if(opcode == 7){
    		
    		int t1 = operand1.value | 0b0000000000000000;
    		int t11 = t1 <<8;
    		int t2 = operand2.value | 0b0000000000000000;
    		int result = t11 | t2;
    		int resultToBeStored = result & 0b00000000000000000000000011111111;
    		
    		int resultSign = (resultToBeStored & 0b00000000000000000000000010000000)>>>7;
    		if(resultSign ==1) {
    			
    			
    			int x = resultToBeStored ^ 0b11111111;
    			int x1 = x+1;
    			resultToBeStored = x1 * -1;
    		}
    		pc.setValue(resultToBeStored);
    		
    		
    		
    		
    	}
       
    	if(cycles.value <= (3 + (instructions.size() -1))) {
    	   decode(fetched_instruction);}
    }
    
    void execute(int opcode,Register operand1,int immediate) throws RegisterValueIsOutOfBounds {
    	status.setStatusRegisterToZero();
    	if(opcode == 3) {
    		int indexOfResult = Integer.parseInt(operand1.name.substring(1));
    		general_purpose_registers.get(indexOfResult).setValue(immediate);
    		
    		
    	}
    	else if(opcode == 4){
    		if(operand1.value ==0)
    			pc.setValue(pc.value + immediate);
    		
    		
    		
    	}
    	else if(opcode == 5){
    		
    		int indexOfResult = Integer.parseInt(operand1.name.substring(1));
    		int result = operand1.value & immediate;
    		int resultToBeStored = result & 0b00000000000000000000000011111111;
    		
    		int resultSign = (resultToBeStored & 0b00000000000000000000000010000000)>>>7;
    		if(resultSign ==1) {
    			
    			
    			int x = resultToBeStored ^ 0b11111111;
    			int x1 = x+1;
    			resultToBeStored = x1 * -1;
    			int newStatus = status.value | 0b00000100;
    			status.setValue(newStatus);
    			System.out.println("The result is negative \n \n");
    		}
    		else {
    			int newStatus = status.value | 0b00000000;
    			status.setValue(newStatus);
    			System.out.println("The result is not negative \n \n");
    			
    		}
    		
    		if(resultToBeStored == 0) {
    			int newStatus = status.value | 0b00000001;
    			status.setValue(newStatus);
    			System.out.println("The Zero Flag is 1");
    			
    		}
    		else {
    			int newStatus = status.value | 0b00000000;
    			status.setValue(newStatus);
    			System.out.println("The Zero Flag is 0");
    			
    		}
    		
    		general_purpose_registers.get(indexOfResult).setValue(resultToBeStored);
    		
    		
    		
    	}
    	else if(opcode == 8){
    		
    		int indexOfResult = Integer.parseInt(operand1.name.substring(1));
    		int result = operand1.value << immediate;
    		int resultToBeStored = result & 0b00000000000000000000000011111111;
    		
    		int resultSign = (resultToBeStored & 0b00000000000000000000000010000000)>>>7;
    		if(resultSign ==1) {
    			
    			
    			int x = resultToBeStored ^ 0b11111111;
    			int x1 = x+1;
    			resultToBeStored = x1 * -1;
    			int newStatus = status.value | 0b00000100;
    			status.setValue(newStatus);
    			System.out.println("The result is negative \n \n");
    		}
    		else {
    			int newStatus = status.value | 0b00000000;
    			status.setValue(newStatus);
    			System.out.println("The result is not negative \n \n");
    			
    		}
    		
    		
    		if(resultToBeStored == 0) {
    			int newStatus = status.value | 0b00000001;
    			status.setValue(newStatus);
    			System.out.println("The Zero Flag is 1");
    			
    		}
    		else {
    			int newStatus = status.value | 0b00000000;
    			status.setValue(newStatus);
    			System.out.println("The Zero Flag is 0");
    			
    		}
    		general_purpose_registers.get(indexOfResult).setValue(resultToBeStored);
    		
    		
    		
    	}
    	else if(opcode == 9){
    		int indexOfResult = Integer.parseInt(operand1.name.substring(1));
    		int result = operand1.value >> immediate;
    		int resultToBeStored = result & 0b00000000000000000000000011111111;
    		
    		int resultSign = (resultToBeStored & 0b00000000000000000000000010000000)>>>7;
    		if(resultSign ==1) {
    			
    			
    			int x = resultToBeStored ^ 0b11111111;
    			int x1 = x+1;
    			resultToBeStored = x1 * -1;
    			int newStatus = status.value | 0b00000100;
    			status.setValue(newStatus);
    			System.out.println("The result is negative \n \n");
    		}
    		else {
    			int newStatus = status.value | 0b00000000;
    			status.setValue(newStatus);
    			System.out.println("The result is not negative \n \n");
    			
    		}
    		
    		if(resultToBeStored == 0) {
    			int newStatus = status.value | 0b00000001;
    			status.setValue(newStatus);
    			System.out.println("The Zero Flag is 1");
    			
    		}
    		else {
    			int newStatus = status.value | 0b00000000;
    			status.setValue(newStatus);
    			System.out.println("The Zero Flag is 0");
    			
    		}
    		general_purpose_registers.get(indexOfResult).setValue(resultToBeStored);
    		
    	}
    	else if(opcode == 10){
    		int indexOfResult = Integer.parseInt(operand1.name.substring(1));
    		int result = data.get(immediate);
    		int resultSign = (result & 0b00000000000000000000000010000000)>>>7;
    		if(resultSign ==1) {
    			
    			
    			int x = result ^ 0b11111111;
    			int x1 = x+1;
    			result = x1 * -1;
    		}
    		general_purpose_registers.get(indexOfResult).setValue(result);
    		
    		
    		
    	}
    	else if(opcode == 11){
    		immediate = immediate & 0b00000000000000000000000011111111;
    		data.add(immediate,operand1.value);
    		System.out.println("Memory is updated at address " + immediate + " with value of " + operand1.value);
    	}
    	
    	
    	if(cycles.value <= (3 + (instructions.size() -1))) {
     	   decode(fetched_instruction);}
    }


    void initialize_general_purpose_registers() throws RegisterValueIsOutOfBounds {
        for (int i = 0; i < 64; ++i) {
            general_purpose_registers.add(new Register("R"+i, 0));
            //System.out.println(general_purpose_registers.get(i).name);
        }    
    }

    
    
    
    public static void main(String[] args) throws RegisterValueIsOutOfBounds, IOException {
        CPU cpu = new CPU();
        cpu.initializeInstructions("Program.txt");
		System.out.println(" \n \n -------------------------------------------------------------------------------------\n  " + " Start of Cycle  1" );
		System.out.println("Program Counter =  0"  );
		cpu.start();
       
    }
}